package hw4;

public class Deck {

	public Deck() {
		// TODO Auto-generated constructor stub
	}

}
